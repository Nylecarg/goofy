//
//  LESSON8challengeeeeApp.swift
//  LESSON8challengeeee
//
//  Created by Gracelyn Gosal on 28/8/23.
//

import SwiftUI

@main
struct LESSON8challengeeeeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
